import React from 'react';
import KycVarification from './Components/KycVarification/KycVarification';

const App = () => {
  return (
    <div>
      <KycVarification></KycVarification>
    </div>
  );
};

export default App;